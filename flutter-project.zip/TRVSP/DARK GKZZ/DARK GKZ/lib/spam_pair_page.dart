import 'dart:convert';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'config.dart';
import 'package:provider/provider.dart';
import 'theme_provider.dart';

class SpamPairPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;
  const SpamPairPage({super.key, required this.sessionKey, required this.username, required this.role});
  @override State<SpamPairPage> createState() => _SpamPairPageState();
}

class _SpamPairPageState extends State<SpamPairPage> with SingleTickerProviderStateMixin {
  final _numCtrl = TextEditingController();
  final _countCtrl = TextEditingController(text: '10');
  final _delayCtrl = TextEditingController(text: '3');
  bool _running = false;
  List<Map<String, dynamic>> _results = [];
  int _sent = 0;
  int _failed = 0;
  int _progress = 0;
  int _total = 0;
  String? _lastCode;
  String? _baileysStatus;
  Timer? _pollTimer;
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  @override void initState() {
    super.initState();
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 800))..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.3, end: 0.8).animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));
  }

  @override void dispose() { _numCtrl.dispose(); _countCtrl.dispose(); _delayCtrl.dispose(); _pulseCtrl.dispose(); _pollTimer?.cancel(); super.dispose(); }

  Future<void> _startSpam() async {
    final num = _numCtrl.text.trim();
    final count = int.tryParse(_countCtrl.text.trim()) ?? 10;
    final delay = int.tryParse(_delayCtrl.text.trim()) ?? 3;
    if (num.isEmpty) return;
    setState(() { _running = true; _results = []; _sent = 0; _failed = 0; _progress = 0; _total = count; _lastCode = null; _baileysStatus = 'Connecting via Baileys...'; });
    
    // Poll pairing codes from Baileys
    _pollTimer = Timer.periodic(const Duration(seconds: 5), (_) => _pollBaileysCode());
    
    try {
      final res = await http.post(
        Uri.parse('${ApiConfig.baseUrl}/api/spam-pair'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'number': num, 'count': count, 'delay': delay, 'key': widget.sessionKey, 'method': 'baileys'}),
      ).timeout(const Duration(seconds: 180));
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        final list = List<Map<String, dynamic>>.from(data['results'] ?? []);
        final sentCount = list.where((r) => r['status'] == 'sent').length;
        setState(() {
          _results = list;
          _sent = sentCount;
          _failed = list.length - sentCount;
          _progress = _total;
          _baileysStatus = data['baileysStatus'] ?? 'Done';
        });
        // Extract pairing codes
        for (final r in list) {
          if (r['code'] != null && r['code'].toString().isNotEmpty) {
            _lastCode = r['code'].toString();
          }
        }
      } else {
        setState(() { _results = [{'error': data['error'] ?? 'Unknown'}]; _progress = _total; _baileysStatus = 'Failed'; });
      }
    } catch (e) {
      setState(() { _results = [{'error': e.toString()}]; _progress = _total; _baileysStatus = 'Error'; });
    } finally {
      _pollTimer?.cancel();
      setState(() => _running = false);
    }
  }

  Future<void> _pollBaileysCode() async {
    try {
      final res = await http.get(
        Uri.parse('${ApiConfig.baseUrl}/api/baileys-status?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 5));
      final data = jsonDecode(res.body);
      if (data['code'] != null && mounted) {
        setState(() {
          _lastCode = data['code'].toString();
          _baileysStatus = data['status'] ?? 'Waiting code...';
        });
      }
    } catch (_) {}
  }

  void _copyCode(String code) {
    Clipboard.setData(ClipboardData(text: code));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Code copied!', style: TextStyle(fontSize: 12)),
        duration: Duration(seconds: 1),
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Provider.of<ThemeProvider>(context);
    const color = Color(0xFFFF6B35);

    return Scaffold(
      backgroundColor: theme.backgroundColor,
      appBar: AppBar(
        backgroundColor: Colors.transparent, elevation: 0,
        title: Row(mainAxisSize: MainAxisSize.min, children: [
          AnimatedBuilder(animation: _pulseAnim, builder: (context, _) {
            return Container(
              width: 8, height: 8,
              decoration: BoxDecoration(
                shape: BoxShape.circle, color: color,
                boxShadow: [BoxShadow(color: color.withOpacity(_pulseAnim.value), blurRadius: 8, spreadRadius: 2)],
              ),
            );
          }),
          const SizedBox(width: 10),
          const Text('SPAM PAIR', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, letterSpacing: 3)),
        ]),
        iconTheme: IconThemeData(color: color, size: 22),
        flexibleSpace: Container(decoration: BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [color.withOpacity(0.06), Colors.transparent]),
          border: Border(bottom: BorderSide(color: Colors.white.withOpacity(0.05))),
        )),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          Container(
            width: double.infinity, padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [theme.glassPrimary, theme.glassSecondary], begin: Alignment.topLeft, end: Alignment.bottomRight),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: color.withOpacity(0.2)),
              boxShadow: [BoxShadow(color: color.withOpacity(0.06), blurRadius: 20, spreadRadius: -4)],
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                AnimatedBuilder(animation: _pulseAnim, builder: (context, _) {
                  return Container(width: 6, height: 6, decoration: BoxDecoration(shape: BoxShape.circle, color: color, boxShadow: [BoxShadow(color: color.withOpacity(_pulseAnim.value), blurRadius: 4)]));
                }),
                const SizedBox(width: 8),
                Text('TARGET CONFIG', style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 3)),
              ]),
              const SizedBox(height: 16),
              TextField(
                controller: _numCtrl, keyboardType: TextInputType.phone,
                style: TextStyle(color: theme.textPrimaryColor, fontSize: 14),
                decoration: InputDecoration(
                  hintText: '628xx...', hintStyle: TextStyle(color: theme.textSecondaryColor, fontSize: 13),
                  prefixIcon: Icon(Icons.phone_rounded, color: color, size: 20),
                  filled: true, fillColor: theme.backgroundColor,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.white.withOpacity(0.06))),
                  enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.white.withOpacity(0.06))),
                  focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: color, width: 1)),
                  contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
                ),
              ),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(child: TextField(
                  controller: _countCtrl, keyboardType: TextInputType.number,
                  style: TextStyle(color: theme.textPrimaryColor, fontSize: 14),
                  decoration: InputDecoration(
                    hintText: 'Jumlah', hintStyle: TextStyle(color: theme.textSecondaryColor, fontSize: 13),
                    labelText: 'Jumlah', labelStyle: TextStyle(color: color.withOpacity(0.6), fontSize: 11),
                    prefixIcon: Icon(Icons.repeat_rounded, color: color, size: 20),
                    filled: true, fillColor: theme.backgroundColor,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.white.withOpacity(0.06))),
                    enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.white.withOpacity(0.06))),
                    focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: color, width: 1)),
                    contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
                  ),
                )),
                const SizedBox(width: 10),
                Expanded(child: TextField(
                  controller: _delayCtrl, keyboardType: TextInputType.number,
                  style: TextStyle(color: theme.textPrimaryColor, fontSize: 14),
                  decoration: InputDecoration(
                    hintText: '3', hintStyle: TextStyle(color: theme.textSecondaryColor, fontSize: 13),
                    labelText: 'Delay (dtk)', labelStyle: TextStyle(color: color.withOpacity(0.6), fontSize: 11),
                    prefixIcon: Icon(Icons.timer_rounded, color: color, size: 20),
                    filled: true, fillColor: theme.backgroundColor,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.white.withOpacity(0.06))),
                    enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.white.withOpacity(0.06))),
                    focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: color, width: 1)),
                    contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
                  ),
                )),
              ]),
              const SizedBox(height: 16),
              Container(
                width: double.infinity, padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: color.withOpacity(0.04), borderRadius: BorderRadius.circular(12), border: Border.all(color: color.withOpacity(0.1))),
                child: Row(children: [
                  AnimatedBuilder(animation: _pulseAnim, builder: (context, _) {
                    return Icon(Icons.warning_amber_rounded, color: color.withOpacity(_pulseAnim.value), size: 16);
                  }),
                  const SizedBox(width: 8),
                  Expanded(child: Text('Mengirim kode pairing via Baileys berulang ke nomor target. Gunakan dengan bijak.', style: TextStyle(color: color.withOpacity(0.8), fontSize: 10, height: 1.3))),
                ]),
              ),
              // Baileys Status
              if (_baileysStatus != null) ...[
                const SizedBox(height: 12),
                Container(
                  width: double.infinity, padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(color: const Color(0xFF1B5E20).withOpacity(0.15), borderRadius: BorderRadius.circular(10), border: Border.all(color: const Color(0xFF2E7D32).withOpacity(0.3))),
                  child: Row(children: [
                    Icon(Icons.chat, color: const Color(0xFF25D366), size: 16),
                    const SizedBox(width: 8),
                    Expanded(child: Text(_baileysStatus!, style: TextStyle(color: const Color(0xFF25D366), fontSize: 10, fontWeight: FontWeight.w600))),
                  ]),
                ),
              ],
              // Last Code from Baileys
              if (_lastCode != null) ...[
                const SizedBox(height: 10),
                Container(
                  width: double.infinity, padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [const Color(0xFF1B5E20), const Color(0xFF0D3310)], begin: Alignment.topLeft, end: Alignment.bottomRight),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: const Color(0xFF25D366).withOpacity(0.5)),
                    boxShadow: [BoxShadow(color: const Color(0xFF25D366).withOpacity(0.2), blurRadius: 12)],
                  ),
                  child: Column(children: [
                    Row(children: [
                      Icon(Icons.vpn_key_rounded, color: const Color(0xFF25D366), size: 18),
                      const SizedBox(width: 8),
                      Text('BAILEYS PAIRING CODE', style: TextStyle(color: const Color(0xFF25D366), fontSize: 9, fontWeight: FontWeight.w800, letterSpacing: 2)),
                    ]),
                    const SizedBox(height: 12),
                    GestureDetector(
                      onTap: () => _copyCode(_lastCode!),
                      child: Container(
                        width: double.infinity, padding: const EdgeInsets.symmetric(vertical: 14),
                        decoration: BoxDecoration(color: Colors.black.withOpacity(0.3), borderRadius: BorderRadius.circular(10), border: Border.all(color: const Color(0xFF25D366).withOpacity(0.3))),
                        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                          Text(_lastCode!, style: const TextStyle(color: Color(0xFF25D366), fontSize: 28, fontWeight: FontWeight.bold, letterSpacing: 6, fontFamily: 'monospace')),
                          const SizedBox(width: 12),
                          const Icon(Icons.copy_rounded, color: Color(0xFF25D366), size: 20),
                        ]),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text('Tap code to copy • Masukkan kode ini di WhatsApp target', style: TextStyle(color: const Color(0xFF25D366).withOpacity(0.6), fontSize: 9)),
                  ]),
                ),
              ],
              const SizedBox(height: 18),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _running ? null : _startSpam,
                  icon: _running
                      ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : const Icon(Icons.rocket_launch_rounded, size: 18),
                  label: Text(_running ? 'SPAMMING...' : 'START SPAM PAIR', style: const TextStyle(fontWeight: FontWeight.bold, letterSpacing: 2, fontSize: 12)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: color, foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    elevation: 8, shadowColor: color.withOpacity(0.4),
                  ),
                ),
              ),
            ]),
          ),
          if (_running) ...[
            const SizedBox(height: 20),
            Container(
              width: double.infinity, padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [theme.glassPrimary, theme.glassSecondary], begin: Alignment.topLeft, end: Alignment.bottomRight),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: color.withOpacity(0.15)),
              ),
              child: Column(children: [
                AnimatedBuilder(animation: _pulseAnim, builder: (context, _) {
                  return SizedBox(
                    width: 60, height: 60,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        SizedBox(width: 60, height: 60, child: CircularProgressIndicator(value: null, strokeWidth: 3, color: color)),
                        Column(mainAxisSize: MainAxisSize.min, children: [
                          Text('$_progress', style: TextStyle(color: color, fontSize: 20, fontWeight: FontWeight.bold)),
                          Text('$_total', style: TextStyle(color: theme.textSecondaryColor, fontSize: 10)),
                        ]),
                      ],
                    ),
                  );
                }),
                const SizedBox(height: 12),
                Text('Mengirim kode pairing...', style: TextStyle(color: theme.textSecondaryColor, fontSize: 11)),
              ]),
            ),
          ],
          if (_results.isNotEmpty) ...[
            const SizedBox(height: 16),
            Row(children: [
              Container(width: 3, height: 18, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(2), boxShadow: [BoxShadow(color: color.withOpacity(0.6), blurRadius: 6)])),
              const SizedBox(width: 10),
              Text('ATTACK LOG', style: TextStyle(color: theme.textPrimaryColor, fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 2)),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(color: Colors.green.withOpacity(0.1), borderRadius: BorderRadius.circular(8), border: Border.all(color: Colors.green.withOpacity(0.2))),
                child: Text('$_sent sent', style: const TextStyle(color: Colors.green, fontSize: 10, fontWeight: FontWeight.bold)),
              ),
              const SizedBox(width: 6),
              if (_failed > 0)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(color: Colors.red.withOpacity(0.1), borderRadius: BorderRadius.circular(8), border: Border.all(color: Colors.red.withOpacity(0.2))),
                  child: Text('$_failed failed', style: const TextStyle(color: Colors.red, fontSize: 10, fontWeight: FontWeight.bold)),
                ),
            ]),
            const SizedBox(height: 10),
            ..._results.map((r) {
              final ok = r['status'] == 'sent';
              return Container(
                width: double.infinity, margin: const EdgeInsets.only(bottom: 6),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [theme.glassPrimary, theme.glassSecondary], begin: Alignment.topLeft, end: Alignment.bottomRight),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: ok ? Colors.green.withOpacity(0.15) : Colors.red.withOpacity(0.15)),
                ),
                child: Row(children: [
                  Container(
                    width: 22, height: 22,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: ok ? Colors.green.withOpacity(0.1) : Colors.red.withOpacity(0.1),
                    ),
                    child: Icon(ok ? Icons.check_rounded : Icons.close_rounded, color: ok ? Colors.green : Colors.red, size: 14),
                  ),
                  const SizedBox(width: 10),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Attempt #${r['attempt']}', style: TextStyle(color: theme.textPrimaryColor, fontSize: 11, fontWeight: FontWeight.w600)),
                    if (r['code'] != null && ok) ...[
                      GestureDetector(
                        onTap: () => _copyCode(r['code'].toString()),
                        child: Row(children: [
                          Text('Code: ', style: TextStyle(color: theme.textSecondaryColor, fontSize: 10)),
                          Text('${r['code']}', style: TextStyle(color: color, fontSize: 10, fontFamily: 'monospace', letterSpacing: 1, fontWeight: FontWeight.bold)),
                          const SizedBox(width: 4),
                          Icon(Icons.copy, color: color, size: 12),
                        ]),
                      ),
                    ],
                    if (r['error'] != null) Text('${r['error']}', style: TextStyle(color: Colors.red, fontSize: 10)),
                    if (r['method'] != null) Text('via ${r['method']}', style: TextStyle(color: color.withOpacity(0.5), fontSize: 8)),
                  ])),
                  if (ok)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(color: Colors.green.withOpacity(0.1), borderRadius: BorderRadius.circular(6), border: Border.all(color: Colors.green.withOpacity(0.3))),
                      child: const Text('SENT', style: TextStyle(color: Colors.green, fontSize: 8, fontWeight: FontWeight.bold)),
                    ),
                ]),
              );
            }),
          ],
        ]),
      ),
    );
  }
}
