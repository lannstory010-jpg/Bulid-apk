import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';
import 'theme_provider.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listGroupBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.listGroupBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final TextEditingController targetController = TextEditingController();
  late final AnimationController _pulseController;
  String selectedBugId = "";
  String _selectedBugMode = "number";

  List<Map<String, dynamic>> get _activeBugList =>
      _selectedBugMode == 'group' ? widget.listGroupBug : widget.listBug;

  void _updateSelectedBugId() {
    final bugList = _activeBugList;
    if (bugList.isNotEmpty) {
      selectedBugId = bugList[0]['bug_id']?.toString() ?? "";
    }
  }

  bool isSending = false;
  String? responseMessage;

  // ============ PRIVATE SENDER (WHATSAPP) ============
  List<Map<String, dynamic>> _privateSenders = [];
  bool _isLoadingSenders = false;
  bool _isAddingSender = false;
  Timer? _senderPollingTimer;
  final TextEditingController _senderInputController = TextEditingController();
  static const String baseUrl = "http://cloudbot.biz.id:4214";
  static const _pollingInterval = Duration(seconds: 10);

  // ============ GLOBAL SENDER (WHATSAPP ONLY) ============
  bool _showGlobalSenderPanel = false;
  final TextEditingController _globalSenderNumberController =
      TextEditingController();
  final TextEditingController _globalMessageController =
      TextEditingController();
  bool _isSendingGlobal = false;
  List<Map<String, dynamic>> _globalSenders = [];
  bool _isLoadingGlobalSenders = false;

  // ============ SENDER TYPE SELECTION ============
  String _selectedSenderType = 'private'; // 'private' atau 'global'

  // Video Player
  late VideoPlayerController _videoController;
  ChewieController? _chewieController;
  bool isVideoInitialized = false;

  bool get _isMember => widget.role.toLowerCase() == 'member';
  bool get _canSendBug => _privateSenders.isNotEmpty;

  bool get _canUseGlobal => true;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _updateSelectedBugId();

    _initializeVideoPlayer();
    _fetchSenders();
    _fetchGlobalSenders();
    _startPolling();
  }

  void _startPolling() {
    _senderPollingTimer = Timer.periodic(_pollingInterval, (_) {
      if (mounted) {
        _fetchSendersSilent();
        _fetchGlobalSendersSilent();
      }
    });
  }

  Future<void> _fetchSendersSilent() async {
    try {
      final res = await http
          .get(Uri.parse("$baseUrl/mySender?key=${widget.sessionKey}"))
          .timeout(const Duration(seconds: 8));
      final data = jsonDecode(res.body);
      if (data["valid"] == true && mounted) {
        final newPrivate = List<Map<String, dynamic>>.from(
          data["privateConnections"] ?? [],
        );
        if (_listChanged(_privateSenders, newPrivate)) {
          setState(() {
            _privateSenders = newPrivate;
          });
        }
      }
    } catch (_) {}
  }

  Future<void> _fetchGlobalSendersSilent() async {
    if (!_canUseGlobal) return;
    try {
      final res = await http
          .get(Uri.parse("$baseUrl/mySender?key=${widget.sessionKey}"))
          .timeout(const Duration(seconds: 8));
      final data = jsonDecode(res.body);
      if (data["valid"] == true && mounted) {
        final newGlobal = List<Map<String, dynamic>>.from(
          data["globalConnections"] ?? [],
        );
        if (_listChanged(_globalSenders, newGlobal)) {
          setState(() {
            _globalSenders = newGlobal;
          });
        }
      }
    } catch (_) {}
  }

  bool _listChanged(
    List<Map<String, dynamic>> oldList,
    List<Map<String, dynamic>> newList,
  ) {
    if (oldList.length != newList.length) return true;
    final oldIds = oldList.map((e) => e['id']?.toString() ?? '').toSet();
    final newIds = newList.map((e) => e['id']?.toString() ?? '').toSet();
    return !oldIds.containsAll(newIds) || !newIds.containsAll(oldIds);
  }

  void _initializeVideoPlayer() {
    _videoController = VideoPlayerController.asset('assets/videos/banner.mp4');

    _videoController
        .initialize()
        .then((_) {
          if (mounted) {
            setState(() {
              _videoController.setVolume(0);
              _chewieController = ChewieController(
                videoPlayerController: _videoController,
                autoPlay: true,
                looping: true,
                showControls: false,
                autoInitialize: true,
              );
              isVideoInitialized = true;
            });
          }
        })
        .catchError((error) {
          debugPrint("Video error: $error");
          if (mounted) {
            setState(() {
              isVideoInitialized = false;
            });
          }
        });
  }

  @override
  void dispose() {
    _senderPollingTimer?.cancel();
    _pulseController.dispose();
    targetController.dispose();
    _videoController.dispose();
    _chewieController?.dispose();
    _senderInputController.dispose();
    _globalSenderNumberController.dispose();
    _globalMessageController.dispose();
    super.dispose();
  }

  Future<void> _fetchSenders() async {
    setState(() => _isLoadingSenders = true);
    try {
      final res = await http.get(
        Uri.parse("$baseUrl/mySender?key=${widget.sessionKey}"),
      );
      final data = jsonDecode(res.body);
      if (data["valid"] == true) {
        setState(() {
          _privateSenders = List<Map<String, dynamic>>.from(
            data["privateConnections"] ?? [],
          );
        });
      }
    } catch (_) {
      _showAlert("❌ Error", "Gagal memuat data private sender.");
    } finally {
      setState(() => _isLoadingSenders = false);
    }
  }

  Future<void> _fetchGlobalSenders() async {
    if (!_canUseGlobal) return;
    setState(() => _isLoadingGlobalSenders = true);
    try {
      final res = await http.get(
        Uri.parse("$baseUrl/mySender?key=${widget.sessionKey}"),
      );
      final data = jsonDecode(res.body);
      if (data["valid"] == true) {
        setState(() {
          _globalSenders = List<Map<String, dynamic>>.from(
            data["globalConnections"] ?? [],
          );
        });
      }
    } catch (_) {
      _showAlert("❌ Error", "Gagal memuat data global sender.");
    } finally {
      setState(() => _isLoadingGlobalSenders = false);
    }
  }

  Future<void> _addSender(String number) async {
    if (number.isEmpty) {
      _showAlert("❌ Error", "Nomor sender tidak boleh kosong.");
      return;
    }
    String formatted = number.trim();
    if (formatted.startsWith('0')) {
      formatted = '62${formatted.substring(1)}';
    } else if (formatted.startsWith('+')) {
      formatted = formatted.replaceAll('+', '');
    } else if (!formatted.startsWith('62')) {
      formatted = '62$formatted';
    }
    setState(() => _isAddingSender = true);
    try {
      final uri = Uri.parse(
        "$baseUrl/getPairing?key=${widget.sessionKey}&number=$formatted&global=0",
      );
      final res = await http.get(uri).timeout(const Duration(seconds: 30));
      final data = jsonDecode(res.body);
      if (data["valid"] == true && data["pairingCode"] != null) {
        try {
          await http
              .post(
                Uri.parse("$baseUrl/addGlobalSender"),
                headers: {"Content-Type": "application/json"},
                body: jsonEncode({
                  "key": widget.sessionKey,
                  "sessionName": formatted,
                }),
              )
              .timeout(const Duration(seconds: 10));
        } catch (_) {}
        _senderInputController.clear();
        _fetchGlobalSendersSilent();
        if (mounted) {
          _showPairingDialog(
            number: formatted,
            pairingCode: data["pairingCode"].toString(),
          );
        }
      } else {
        final msg =
            data["message"] ??
            data["error"] ??
            "Gagal mendapatkan pairing code.";
        _showAlert("❌ Gagal", msg);
      }
    } on SocketException {
      _showAlert("❌ Error", "Tidak ada koneksi internet.");
    } catch (e) {
      _showAlert("❌ Error", "Terjadi kesalahan: $e");
    } finally {
      if (mounted) setState(() => _isAddingSender = false);
    }
  }

  void _showPairingDialog({
    required String number,
    required String pairingCode,
  }) {
    final theme = Provider.of<ThemeProvider>(context, listen: false);
    final formatted = pairingCode.length == 8
        ? '${pairingCode.substring(0, 4)}-${pairingCode.substring(4)}'
        : pairingCode;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: theme.backgroundColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: BorderSide(
            color: theme.primaryColor.withOpacity(0.4),
            width: 1,
          ),
        ),
        title: Row(
          children: [
            Icon(
              FontAwesomeIcons.whatsapp,
              color: theme.primaryColor,
              size: 20,
            ),
            const SizedBox(width: 10),
            Text(
              "Private Sender Pairing",
              style: TextStyle(
                color: theme.textPrimaryColor,
                fontFamily: 'Orbitron',
                fontSize: 14,
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              "Masukkan kode ini di WhatsApp nomor:",
              style: TextStyle(
                color: theme.textSecondaryColor,
                fontFamily: 'ShareTechMono',
                fontSize: 12,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              number,
              style: TextStyle(
                color: theme.primaryColor,
                fontFamily: 'ShareTechMono',
                fontSize: 13,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
              decoration: BoxDecoration(
                color: theme.primaryColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: theme.primaryColor.withOpacity(0.4)),
              ),
              child: Text(
                formatted,
                style: TextStyle(
                  color: theme.textPrimaryColor,
                  fontFamily: 'Orbitron',
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 8,
                ),
              ),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: theme.glassSecondary,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _pairingStep("1", "Buka WhatsApp di HP nomor $number", theme),
                  _pairingStep("2", "Ketuk ⋮ Menu → Perangkat Tertaut", theme),
                  _pairingStep(
                    "3",
                    "Ketuk \"Tautkan dengan nomor telepon\"",
                    theme,
                  ),
                  _pairingStep("4", "Masukkan kode di atas", theme),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Text(
              "Kode berlaku ±60 detik.",
              style: TextStyle(
                color: theme.textSecondaryColor,
                fontFamily: 'ShareTechMono',
                fontSize: 10,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _fetchSenders();
            },
            child: Text(
              "Selesai",
              style: TextStyle(
                color: theme.primaryColor,
                fontFamily: 'Orbitron',
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _pairingStep(String step, String text, ThemeProvider theme) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 20,
            height: 20,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: theme.primaryColor.withOpacity(0.2),
              shape: BoxShape.circle,
            ),
            child: Text(
              step,
              style: TextStyle(
                color: theme.primaryColor,
                fontSize: 11,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                color: theme.textSecondaryColor,
                fontFamily: 'ShareTechMono',
                fontSize: 11,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _deleteSender(String number) async {
    try {
      final res = await http.delete(
        Uri.parse(
          "$baseUrl/deleteSender?key=${widget.sessionKey}&id=$number&scope=private",
        ),
      );
      final data = jsonDecode(res.body);
      if (data["valid"] == true) {
        _showAlert("✅ Berhasil", "Private sender berhasil dihapus.");
        await _fetchSenders();
      } else {
        _showAlert("❌ Gagal", data["message"] ?? "Gagal menghapus sender.");
      }
    } catch (_) {
      _showAlert("❌ Error", "Terjadi kesalahan saat menghapus sender.");
    }
  }

  void _showDeleteConfirmation(String number, {bool isGlobal = false}) {
    final theme = Provider.of<ThemeProvider>(context, listen: false);
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: theme.backgroundColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: BorderSide(
            color: theme.primaryColor.withOpacity(0.4),
            width: 1,
          ),
        ),
        title: Text(
          "⚠️ Konfirmasi Hapus",
          style: TextStyle(
            color: theme.textPrimaryColor,
            fontFamily: 'Orbitron',
            fontSize: 15,
          ),
        ),
        content: Text(
          "Hapus ${isGlobal ? 'global' : 'private'} sender $number dari daftar?",
          style: TextStyle(
            color: theme.textSecondaryColor,
            fontFamily: 'ShareTechMono',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              "Batal",
              style: TextStyle(color: theme.textSecondaryColor),
            ),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              if (isGlobal) {
                _deleteGlobalSender(number);
              } else {
                _deleteSender(number);
              }
            },
            child: const Text("Hapus", style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  Future<void> _deleteGlobalSender(String number) async {
    try {
      final res = await http.delete(
        Uri.parse(
          "$baseUrl/deleteSender?key=${widget.sessionKey}&id=$number&scope=global",
        ),
      );
      final data = jsonDecode(res.body);
      if (data["valid"] == true) {
        _showAlert("✅ Berhasil", "Global sender berhasil dihapus.");
        await _fetchGlobalSenders();
      } else {
        _showAlert(
          "❌ Gagal",
          data["message"] ?? "Gagal menghapus global sender.",
        );
      }
    } catch (_) {
      _showAlert("❌ Error", "Terjadi kesalahan saat menghapus global sender.");
    }
  }

  String? _formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  bool isValidGroupLink(String input) {
    return input.contains('chat.whatsapp.com') && input.contains('https://');
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;

    if (_selectedBugMode == "number") {
      final target = _formatPhoneNumber(rawInput);
      if (target == null || key.isEmpty) {
        _showMessageDialog(
          "Invalid Number",
          "Use international format (e.g., +62, +1, +44)",
        );
        return;
      }
    } else {
      if (!isValidGroupLink(rawInput)) {
        _showMessageDialog("Invalid Link", "Enter a valid WhatsApp group link");
        return;
      }
    }

    if (_selectedSenderType == 'private' && !_canSendBug) {
      _showAlert(
        "❌ No Private Sender",
        "Tambahkan private sender terlebih dahulu!",
      );
      return;
    }
    if (_selectedSenderType == 'global' && _globalSenders.isEmpty) {
      _showAlert(
        "❌ No Global Sender",
        "Belum ada global sender aktif. Hubungi owner!",
      );
      return;
    }

    setState(() {
      isSending = true;
      responseMessage = null;
    });

    try {
      final res = await http
          .get(
            Uri.parse(
              "$baseUrl/sendBug?key=$key&target=$rawInput&bug=$selectedBugId&senderType=$_selectedSenderType",
            ),
          )
          .timeout(const Duration(seconds: 30));

      final data = jsonDecode(res.body);

      if (!mounted) return;

      if (data["cooldown"] == true) {
        final wait = data["wait"];
        setState(
          () => responseMessage = wait == null
              ? "⏳ Cooldown: Please wait a moment"
              : "⏳ Cooldown: Wait $wait seconds",
        );
      } else if (data["valid"] == false) {
        setState(
          () => responseMessage = "❌ Invalid Session: Please login again",
        );
      } else if (data["sended"] == false) {
        setState(
          () =>
              responseMessage = "⚠️ ${data["message"] ?? "Failed to send bug"}",
        );
      } else {
        setState(() => responseMessage = "✅ Attack sent successfully!");
        targetController.clear();
      }
    } catch (e) {
      if (mounted) {
        setState(() => responseMessage = "❌ Error: Connection failed");
      }
    } finally {
      if (mounted) {
        setState(() => isSending = false);
      }
    }
  }

  Future<void> _sendGlobalMessage() async {
    final targetNumber = _globalSenderNumberController.text.trim();
    final message = _globalMessageController.text.trim();

    if (targetNumber.isEmpty) {
      _showAlert("❌ Error", "Masukkan nomor target!");
      return;
    }
    if (message.isEmpty) {
      _showAlert("❌ Error", "Masukkan pesan yang akan dikirim!");
      return;
    }

    final formattedTarget = _formatPhoneNumber(targetNumber);
    if (formattedTarget == null) {
      _showAlert("❌ Error", "Format nomor tidak valid! Gunakan format +62xxx");
      return;
    }

    setState(() => _isSendingGlobal = true);

    try {
      final res = await http
          .get(
            Uri.parse(
              "$baseUrl/sendMessageViaGlobal?key=${widget.sessionKey}&target=$formattedTarget&message=${Uri.encodeComponent(message)}",
            ),
          )
          .timeout(const Duration(seconds: 30));

      final data = jsonDecode(res.body);

      if (data["success"] == true) {
        _showAlert(
          "✅ Berhasil",
          "Pesan berhasil dikirim ke $formattedTarget via Global Sender!",
        );
        _globalMessageController.clear();
        _globalSenderNumberController.clear();
      } else {
        _showAlert(
          "❌ Gagal",
          data["message"] ?? "Gagal mengirim pesan via Global Sender",
        );
      }
    } catch (e) {
      _showAlert("❌ Error", "Terjadi kesalahan: $e");
    } finally {
      setState(() => _isSendingGlobal = false);
    }
  }

  void _showAlert(String title, String msg) {
    final theme = Provider.of<ThemeProvider>(context, listen: false);
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: theme.backgroundColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: BorderSide(
            color: theme.primaryColor.withOpacity(0.3),
            width: 1,
          ),
        ),
        title: Text(
          title,
          style: TextStyle(
            color: theme.textPrimaryColor,
            fontFamily: 'Orbitron',
          ),
        ),
        content: Text(
          msg,
          style: TextStyle(
            color: theme.textSecondaryColor,
            fontFamily: 'ShareTechMono',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK", style: TextStyle(color: theme.primaryColor)),
          ),
        ],
      ),
    );
  }

  void _showMessageDialog(String title, String msg) {
    final theme = Provider.of<ThemeProvider>(context, listen: false);
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          margin: const EdgeInsets.all(20),
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                theme.backgroundColor,
                theme.backgroundColor.withOpacity(0.95),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(32),
            border: Border.all(
              color: theme.primaryColor.withOpacity(0.3),
              width: 1.5,
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [theme.primaryColor, theme.accentColor],
                  ),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.warning_rounded,
                  color: Colors.white,
                  size: 32,
                ),
              ),
              const SizedBox(height: 20),
              Text(
                title,
                style: TextStyle(
                  color: theme.textPrimaryColor,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                msg,
                textAlign: TextAlign.center,
                style: TextStyle(color: theme.textSecondaryColor, fontSize: 14),
              ),
              const SizedBox(height: 24),
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [theme.primaryColor, theme.accentColor],
                    ),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const Center(
                    child: Text(
                      "OK",
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Provider.of<ThemeProvider>(context);

    final double glow = _pulseController.value;

    return Scaffold(
      backgroundColor: theme.backgroundColor,
      body: Stack(
        children: [
          // Video Background
          if (isVideoInitialized)
            Positioned.fill(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController.value.size.width,
                  height: _videoController.value.size.height,
                  child: VideoPlayer(_videoController),
                ),
              ),
            ),
          // Dark Overlay for readability
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.black.withOpacity(0.6),
                  Colors.black.withOpacity(0.3),
                  Colors.black.withOpacity(0.6),
                ],
              ),
            ),
          ),
          // Content
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
              child: Column(
              children: [
                // ── Profile Banner ──────────────────────────────
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        theme.primaryColor.withOpacity(0.25),
                        theme.accentColor.withOpacity(0.15),
                        theme.glassPrimary,
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(28),
                    border: Border.all(
                      color: theme.primaryColor.withOpacity(0.2),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: theme.primaryColor.withOpacity(0.1 * glow),
                        blurRadius: 30,
                        spreadRadius: -8,
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 52,
                            height: 52,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [theme.primaryColor, theme.accentColor],
                              ),
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: theme.primaryColor.withOpacity(0.4),
                                  blurRadius: 16,
                                ),
                              ],
                            ),
                            child: ClipOval(
                              child: Image.asset(
                                'assets/images/logo.png',
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => Icon(
                                  Icons.person,
                                  color: theme.textPrimaryColor,
                                  size: 28,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  widget.username,
                                  style: TextStyle(
                                    color: theme.textPrimaryColor,
                                    fontSize: 17,
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 0.5,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Row(
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 8,
                                        vertical: 3,
                                      ),
                                      decoration: BoxDecoration(
                                        gradient: LinearGradient(
                                          colors: [
                                            theme.primaryColor,
                                            theme.accentColor,
                                          ],
                                        ),
                                        borderRadius: BorderRadius.circular(6),
                                      ),
                                      child: Text(
                                        widget.role.toUpperCase(),
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 8,
                                          fontWeight: FontWeight.bold,
                                          letterSpacing: 1,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    Icon(
                                      Icons.access_time_rounded,
                                      color: theme.textSecondaryColor,
                                      size: 10,
                                    ),
                                    const SizedBox(width: 3),
                                    Text(
                                      widget.expiredDate,
                                      style: TextStyle(
                                        color: theme.textSecondaryColor,
                                        fontSize: 9,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      // ── Stats Row ──
                      Row(
                        children: [
                          Expanded(
                            child: _statTile(
                              icon: Icons.phone_android_rounded,
                              label: 'PRIVATE',
                              value: '${_privateSenders.length}',
                              color: theme.primaryColor,
                              theme: theme,
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: _statTile(
                              icon: Icons.public_rounded,
                              label: 'GLOBAL',
                              value: '${_globalSenders.length}',
                              color: Colors.green,
                              theme: theme,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 16),

                // ── Attack Card ────────────────────────────────
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: theme.glassPrimary,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(
                      color: theme.primaryColor.withOpacity(0.12),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: theme.primaryColor.withOpacity(0.05),
                        blurRadius: 20,
                        spreadRadius: -6,
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(
                            Icons.rocket_launch_rounded,
                            color: theme.primaryColor,
                            size: 16,
                          ),
                          const SizedBox(width: 8),
                          Text(
                            'ATTACK PANEL',
                            style: TextStyle(
                              color: theme.textPrimaryColor,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.5,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      // Mode Tabs
                      Container(
                        padding: const EdgeInsets.all(3),
                        decoration: BoxDecoration(
                          color: theme.glassSecondary,
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Row(
                          children: [
                            _buildModeTab(
                              label: "NOMOR",
                              icon: Icons.phone_android_rounded,
                              mode: "number",
                              theme: theme,
                            ),
                            _buildModeTab(
                              label: "GROUP",
                              icon: Icons.group_rounded,
                              mode: "group",
                              theme: theme,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),
                      // Target Input
                      Container(
                        decoration: BoxDecoration(
                          color: theme.glassSecondary,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: theme.textPrimaryColor.withOpacity(0.06),
                          ),
                        ),
                        child: TextField(
                          controller: targetController,
                          style: TextStyle(
                            color: theme.textPrimaryColor,
                            fontSize: 13,
                          ),
                          cursorColor: theme.primaryColor,
                          keyboardType: _selectedBugMode == "number"
                              ? TextInputType.phone
                              : TextInputType.url,
                          decoration: InputDecoration(
                            hintText: _selectedBugMode == "number"
                                ? "+62xxxxxxxxxx"
                                : "https://chat.whatsapp.com/...",
                            hintStyle: TextStyle(
                              color: theme.textSecondaryColor.withOpacity(0.4),
                              fontSize: 13,
                            ),
                            border: InputBorder.none,
                            prefixIcon: Icon(
                              _selectedBugMode == "number"
                                  ? Icons.phone_android_rounded
                                  : Icons.link_rounded,
                              color: theme.primaryColor,
                              size: 18,
                            ),
                            contentPadding: const EdgeInsets.symmetric(
                              vertical: 14,
                              horizontal: 16,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 14),
                      // Bug Selector
                      Row(
                        children: [
                          Container(
                            width: 3,
                            height: 14,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [theme.primaryColor, theme.accentColor],
                              ),
                              borderRadius: BorderRadius.circular(2),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            "PILIH BUG",
                            style: TextStyle(
                              color: theme.textSecondaryColor,
                              fontSize: 10,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 1.5,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      SizedBox(
                        height: 100,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          physics: const BouncingScrollPhysics(),
                          itemCount: _activeBugList.length,
                          itemBuilder: (context, index) {
                            final bug = _activeBugList[index];
                            final isSelected = selectedBugId == bug['bug_id'];
                            return GestureDetector(
                              onTap: () =>
                                  setState(() => selectedBugId = bug['bug_id']),
                              child: Container(
                                width: 110,
                                margin: const EdgeInsets.only(right: 10),
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  gradient: isSelected
                                      ? LinearGradient(
                                          colors: [
                                            theme.primaryColor,
                                            theme.accentColor,
                                          ],
                                          begin: Alignment.topLeft,
                                          end: Alignment.bottomRight,
                                        )
                                      : null,
                                  color: isSelected
                                      ? null
                                      : theme.glassSecondary,
                                  borderRadius: BorderRadius.circular(18),
                                  border: Border.all(
                                    color: isSelected
                                        ? theme.primaryColor
                                        : theme.textPrimaryColor.withOpacity(
                                            0.05,
                                          ),
                                    width: isSelected ? 1.5 : 1,
                                  ),
                                  boxShadow: isSelected
                                      ? [
                                          BoxShadow(
                                            color: theme.primaryColor
                                                .withOpacity(0.2),
                                            blurRadius: 12,
                                          ),
                                        ]
                                      : null,
                                ),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      Icons.bug_report,
                                      color: isSelected
                                          ? Colors.white
                                          : theme.primaryColor,
                                      size: 22,
                                    ),
                                    const SizedBox(height: 6),
                                    Text(
                                      bug['bug_name'],
                                      style: TextStyle(
                                        color: isSelected
                                            ? Colors.white
                                            : theme.textPrimaryColor,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 10,
                                      ),
                                      textAlign: TextAlign.center,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    const SizedBox(height: 3),
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 5,
                                        vertical: 1,
                                      ),
                                      decoration: BoxDecoration(
                                        color: isSelected
                                            ? Colors.white.withOpacity(0.2)
                                            : theme.primaryColor.withOpacity(
                                                0.1,
                                              ),
                                        borderRadius: BorderRadius.circular(5),
                                      ),
                                      child: Text(
                                        "ID: ${bug['bug_id']}",
                                        style: TextStyle(
                                          color: isSelected
                                              ? Colors.white
                                              : theme.primaryColor,
                                          fontSize: 8,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 16),

                // ============ SENDER CARD ============
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: theme.glassPrimary,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(
                      color: theme.primaryColor.withOpacity(0.12),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.green.withOpacity(0.04),
                        blurRadius: 24,
                        spreadRadius: -8,
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(6),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [Color(0xFF25D366), Color(0xFF128C7E)],
                              ),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Icon(
                              FontAwesomeIcons.whatsapp,
                              color: Colors.white,
                              size: 12,
                            ),
                          ),
                          const SizedBox(width: 10),
                          Text(
                            "WHATSAPP SENDER",
                            style: TextStyle(
                              color: theme.textPrimaryColor,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1,
                            ),
                          ),
                          const Spacer(),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 3,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.green.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                color: Colors.green.withOpacity(0.2),
                              ),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  Icons.public_rounded,
                                  color: Colors.green,
                                  size: 9,
                                ),
                                const SizedBox(width: 3),
                                Text(
                                  'G: ${_globalSenders.length}',
                                  style: TextStyle(
                                    color: Colors.green,
                                    fontSize: 9,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      Row(
                        children: [
                          Expanded(
                            child: Container(
                              height: 44,
                              decoration: BoxDecoration(
                                color: theme.glassSecondary,
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: theme.textPrimaryColor.withOpacity(
                                    0.06,
                                  ),
                                ),
                              ),
                              child: TextField(
                                controller: _senderInputController,
                                style: TextStyle(
                                  color: theme.textPrimaryColor,
                                  fontSize: 13,
                                ),
                                decoration: InputDecoration(
                                  hintText: "628xx",
                                  hintStyle: TextStyle(
                                    color: theme.textSecondaryColor.withOpacity(
                                      0.35,
                                    ),
                                    fontSize: 13,
                                  ),
                                  prefixIcon: Icon(
                                    Icons.phone_rounded,
                                    color: theme.primaryColor,
                                    size: 15,
                                  ),
                                  border: InputBorder.none,
                                  contentPadding: const EdgeInsets.symmetric(
                                    horizontal: 12,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          GestureDetector(
                            onTap: _isAddingSender
                                ? null
                                : () => _addSender(
                                    _senderInputController.text.trim(),
                                  ),
                            child: Container(
                              width: 44,
                              height: 44,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    Color(0xFF25D366),
                                    Color(0xFF128C7E),
                                  ],
                                ),
                                borderRadius: BorderRadius.circular(12),
                                boxShadow: [
                                  BoxShadow(
                                    color: Color(0xFF25D366).withOpacity(0.3),
                                    blurRadius: 8,
                                  ),
                                ],
                              ),
                              child: Center(
                                child: _isAddingSender
                                    ? SizedBox(
                                        width: 18,
                                        height: 18,
                                        child: CircularProgressIndicator(
                                          strokeWidth: 2,
                                          color: Colors.white,
                                        ),
                                      )
                                    : Icon(
                                        Icons.add,
                                        color: Colors.white,
                                        size: 20,
                                      ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      if (_isLoadingSenders)
                        const Center(
                          child: Padding(
                            padding: EdgeInsets.all(16),
                            child: CircularProgressIndicator(strokeWidth: 2),
                          ),
                        )
                      else if (_privateSenders.isEmpty)
                        Center(
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 20),
                            child: Column(
                              children: [
                                Icon(
                                  Icons.phone_android_rounded,
                                  color: theme.textSecondaryColor.withOpacity(
                                    0.2,
                                  ),
                                  size: 28,
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  "Belum ada sender",
                                  style: TextStyle(
                                    color: theme.textSecondaryColor,
                                    fontSize: 11,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        )
                      else
                        ..._privateSenders.map(
                          (sender) => Container(
                            margin: const EdgeInsets.only(bottom: 6),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 9,
                            ),
                            decoration: BoxDecoration(
                              color: theme.glassSecondary,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                color: theme.textPrimaryColor.withOpacity(0.03),
                              ),
                            ),
                            child: Row(
                              children: [
                                Container(
                                  width: 6,
                                  height: 6,
                                  decoration: BoxDecoration(
                                    color: Colors.greenAccent,
                                    shape: BoxShape.circle,
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.greenAccent.withOpacity(
                                          0.4,
                                        ),
                                        blurRadius: 4,
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Text(
                                    sender['sessionName'] ??
                                        sender['id'] ??
                                        'Unknown',
                                    style: TextStyle(
                                      color: theme.textPrimaryColor,
                                      fontSize: 12,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                                GestureDetector(
                                  onTap: () => _showDeleteConfirmation(
                                    sender['sessionName'] ?? sender['id'] ?? '',
                                  ),
                                  child: Container(
                                    padding: const EdgeInsets.all(6),
                                    decoration: BoxDecoration(
                                      color: theme.primaryColor.withOpacity(
                                        0.06,
                                      ),
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    child: Icon(
                                      Icons.delete_outline,
                                      color: theme.primaryColor,
                                      size: 14,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                    ],
                  ),
                ),

                const SizedBox(height: 16),

                // ============ GLOBAL SENDER PANEL ============
                if (!_showGlobalSenderPanel)
                  GestureDetector(
                    onTap: () {
                      setState(() => _showGlobalSenderPanel = true);
                      _fetchGlobalSenders();
                    },
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.green.withOpacity(0.08),
                            const Color(0xFF128C7E).withOpacity(0.03),
                          ],
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                        ),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: Colors.green.withOpacity(0.12),
                        ),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            padding: const EdgeInsets.all(4),
                            decoration: BoxDecoration(
                              color: Colors.green.withOpacity(0.15),
                              shape: BoxShape.circle,
                            ),
                            child: Icon(
                              Icons.public_rounded,
                              color: Colors.green,
                              size: 14,
                            ),
                          ),
                          const SizedBox(width: 10),
                          Text(
                            "GLOBAL SENDER",
                            style: TextStyle(
                              color: Colors.green,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1,
                            ),
                          ),
                          const SizedBox(width: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 6,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.green.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(
                              '${_globalSenders.length}',
                              style: TextStyle(
                                color: Colors.green,
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          const SizedBox(width: 6),
                          Icon(
                            Icons.chevron_right_rounded,
                            color: Colors.green,
                            size: 16,
                          ),
                        ],
                      ),
                    ),
                  )
                else
                  Container(
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      color: theme.glassPrimary,
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(color: Colors.green.withOpacity(0.15)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(5),
                              decoration: BoxDecoration(
                                color: Colors.green.withOpacity(0.12),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Icon(
                                FontAwesomeIcons.globe,
                                color: Colors.green,
                                size: 12,
                              ),
                            ),
                            const SizedBox(width: 10),
                            Text(
                              "GLOBAL SENDER",
                              style: TextStyle(
                                color: theme.textPrimaryColor,
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 1,
                              ),
                            ),
                            const Spacer(),
                            GestureDetector(
                              onTap: () => setState(
                                () => _showGlobalSenderPanel = false,
                              ),
                              child: Container(
                                padding: const EdgeInsets.all(4),
                                decoration: BoxDecoration(
                                  color: theme.textSecondaryColor.withOpacity(
                                    0.08,
                                  ),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Icon(
                                  Icons.close,
                                  color: theme.textSecondaryColor,
                                  size: 14,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 14),
                        if (_isLoadingGlobalSenders)
                          const Center(
                            child: Padding(
                              padding: EdgeInsets.all(16),
                              child: CircularProgressIndicator(strokeWidth: 2),
                            ),
                          )
                        else if (_globalSenders.isEmpty)
                          Center(
                            child: Container(
                              padding: const EdgeInsets.symmetric(vertical: 20),
                              child: Column(
                                children: [
                                  Icon(
                                    Icons.public_off_rounded,
                                    color: theme.textSecondaryColor.withOpacity(
                                      0.2,
                                    ),
                                    size: 26,
                                  ),
                                  const SizedBox(height: 6),
                                  Text(
                                    "Belum ada global sender",
                                    style: TextStyle(
                                      color: theme.textSecondaryColor,
                                      fontSize: 11,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          )
                        else
                          ..._globalSenders.map(
                            (sender) => Container(
                              margin: const EdgeInsets.only(bottom: 6),
                              padding: const EdgeInsets.symmetric(
                                horizontal: 12,
                                vertical: 9,
                              ),
                              decoration: BoxDecoration(
                                color: theme.glassSecondary,
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                  color: theme.textPrimaryColor.withOpacity(
                                    0.03,
                                  ),
                                ),
                              ),
                              child: Row(
                                children: [
                                  Container(
                                    width: 6,
                                    height: 6,
                                    decoration: BoxDecoration(
                                      color: Colors.greenAccent,
                                      shape: BoxShape.circle,
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.greenAccent.withOpacity(
                                            0.4,
                                          ),
                                          blurRadius: 4,
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Text(
                                      sender['sessionName'] ??
                                          sender['id'] ??
                                          'Unknown',
                                      style: TextStyle(
                                        color: theme.textPrimaryColor,
                                        fontSize: 12,
                                      ),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  GestureDetector(
                                    onTap: () => _showDeleteConfirmation(
                                      sender['sessionName'] ??
                                          sender['id'] ??
                                          '',
                                      isGlobal: true,
                                    ),
                                    child: Container(
                                      padding: const EdgeInsets.all(6),
                                      decoration: BoxDecoration(
                                        color: theme.primaryColor.withOpacity(
                                          0.06,
                                        ),
                                        borderRadius: BorderRadius.circular(6),
                                      ),
                                      child: Icon(
                                        Icons.delete_outline,
                                        color: theme.primaryColor,
                                        size: 14,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        const SizedBox(height: 14),
                        Divider(
                          color: theme.textSecondaryColor.withOpacity(0.08),
                          height: 1,
                        ),
                        const SizedBox(height: 14),
                        Row(
                          children: [
                            Icon(
                              Icons.send_rounded,
                              color: Colors.green,
                              size: 12,
                            ),
                            const SizedBox(width: 6),
                            Text(
                              "KIRIM PESAN VIA GLOBAL",
                              style: TextStyle(
                                color: theme.textSecondaryColor,
                                fontSize: 9,
                                fontWeight: FontWeight.w600,
                                letterSpacing: 1,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Container(
                          decoration: BoxDecoration(
                            color: theme.glassSecondary,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: theme.textPrimaryColor.withOpacity(0.06),
                            ),
                          ),
                          child: TextField(
                            controller: _globalSenderNumberController,
                            style: TextStyle(
                              color: theme.textPrimaryColor,
                              fontSize: 13,
                            ),
                            keyboardType: TextInputType.phone,
                            decoration: InputDecoration(
                              hintText: "Nomor Target (+62xx)",
                              hintStyle: TextStyle(
                                color: theme.textSecondaryColor.withOpacity(
                                  0.35,
                                ),
                                fontSize: 13,
                              ),
                              prefixIcon: Icon(
                                Icons.phone,
                                color: theme.primaryColor,
                                size: 15,
                              ),
                              border: InputBorder.none,
                              contentPadding: const EdgeInsets.symmetric(
                                horizontal: 14,
                                vertical: 10,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 10),
                        Container(
                          decoration: BoxDecoration(
                            color: theme.glassSecondary,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: theme.textPrimaryColor.withOpacity(0.06),
                            ),
                          ),
                          child: TextField(
                            controller: _globalMessageController,
                            style: TextStyle(
                              color: theme.textPrimaryColor,
                              fontSize: 13,
                            ),
                            maxLines: 2,
                            decoration: InputDecoration(
                              hintText: "Pesan",
                              hintStyle: TextStyle(
                                color: theme.textSecondaryColor.withOpacity(
                                  0.35,
                                ),
                                fontSize: 13,
                              ),
                              prefixIcon: Icon(
                                Icons.message,
                                color: theme.primaryColor,
                                size: 15,
                              ),
                              border: InputBorder.none,
                              contentPadding: const EdgeInsets.symmetric(
                                horizontal: 14,
                                vertical: 10,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 12),
                        SizedBox(
                          width: double.infinity,
                          height: 42,
                          child: ElevatedButton.icon(
                            onPressed: _isSendingGlobal
                                ? null
                                : _sendGlobalMessage,
                            icon: _isSendingGlobal
                                ? SizedBox(
                                    width: 16,
                                    height: 16,
                                    child: CircularProgressIndicator(
                                      color: Colors.white,
                                      strokeWidth: 2,
                                    ),
                                  )
                                : Icon(
                                    FontAwesomeIcons.paperPlane,
                                    color: Colors.white,
                                    size: 12,
                                  ),
                            label: Text(
                              _isSendingGlobal ? "SENDING..." : "KIRIM PESAN",
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 1,
                              ),
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.green.withOpacity(0.15),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                                side: BorderSide(
                                  color: Colors.green.withOpacity(0.3),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                const SizedBox(height: 16),

                // ─── SENDER TYPE TOGGLE ───────────────────────
                Container(
                  padding: const EdgeInsets.all(3),
                  decoration: BoxDecoration(
                    color: theme.glassSecondary,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: theme.textPrimaryColor.withOpacity(0.06),
                    ),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: GestureDetector(
                          onTap: () =>
                              setState(() => _selectedSenderType = 'private'),
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            padding: const EdgeInsets.symmetric(vertical: 9),
                            decoration: BoxDecoration(
                              color: _selectedSenderType == 'private'
                                  ? theme.primaryColor.withOpacity(0.15)
                                  : Colors.transparent,
                              borderRadius: BorderRadius.circular(9),
                              border: Border.all(
                                color: _selectedSenderType == 'private'
                                    ? theme.primaryColor.withOpacity(0.3)
                                    : Colors.transparent,
                              ),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.lock_rounded,
                                  size: 13,
                                  color: _selectedSenderType == 'private'
                                      ? theme.primaryColor
                                      : theme.textSecondaryColor,
                                ),
                                const SizedBox(width: 5),
                                Text(
                                  'PRIVATE',
                                  style: TextStyle(
                                    color: _selectedSenderType == 'private'
                                        ? theme.primaryColor
                                        : theme.textSecondaryColor,
                                    fontSize: 10,
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 1,
                                  ),
                                ),
                                if (_privateSenders.isNotEmpty) ...[
                                  const SizedBox(width: 4),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 4,
                                      vertical: 1,
                                    ),
                                    decoration: BoxDecoration(
                                      color: _selectedSenderType == 'private'
                                          ? theme.primaryColor.withOpacity(0.2)
                                          : theme.textSecondaryColor
                                                .withOpacity(0.15),
                                      borderRadius: BorderRadius.circular(4),
                                    ),
                                    child: Text(
                                      '${_privateSenders.length}',
                                      style: TextStyle(
                                        color: _selectedSenderType == 'private'
                                            ? theme.primaryColor
                                            : theme.textSecondaryColor,
                                        fontSize: 8,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ],
                              ],
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: GestureDetector(
                          onTap: () =>
                              setState(() => _selectedSenderType = 'global'),
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            padding: const EdgeInsets.symmetric(vertical: 9),
                            decoration: BoxDecoration(
                              color: _selectedSenderType == 'global'
                                  ? Colors.green.withOpacity(0.12)
                                  : Colors.transparent,
                              borderRadius: BorderRadius.circular(9),
                              border: Border.all(
                                color: _selectedSenderType == 'global'
                                    ? Colors.green.withOpacity(0.25)
                                    : Colors.transparent,
                              ),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.public_rounded,
                                  size: 13,
                                  color: _selectedSenderType == 'global'
                                      ? Colors.green
                                      : theme.textSecondaryColor,
                                ),
                                const SizedBox(width: 5),
                                Text(
                                  'GLOBAL',
                                  style: TextStyle(
                                    color: _selectedSenderType == 'global'
                                        ? Colors.green
                                        : theme.textSecondaryColor,
                                    fontSize: 10,
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 1,
                                  ),
                                ),
                                if (_globalSenders.isNotEmpty) ...[
                                  const SizedBox(width: 4),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 4,
                                      vertical: 1,
                                    ),
                                    decoration: BoxDecoration(
                                      color: _selectedSenderType == 'global'
                                          ? Colors.green.withOpacity(0.2)
                                          : theme.textSecondaryColor
                                                .withOpacity(0.15),
                                      borderRadius: BorderRadius.circular(4),
                                    ),
                                    child: Text(
                                      '${_globalSenders.length}',
                                      style: TextStyle(
                                        color: _selectedSenderType == 'global'
                                            ? Colors.green
                                            : theme.textSecondaryColor,
                                        fontSize: 8,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ],
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 14),

                // Send Bug Button
                AnimatedBuilder(
                  animation: _pulseController,
                  builder: (context, child) {
                    final bool canSend = _selectedSenderType == 'private'
                        ? _canSendBug
                        : _globalSenders.isNotEmpty;
                    final String btnLabel = _selectedSenderType == 'private'
                        ? (!_canSendBug ? "TAMBAH SENDER DULU" : "SEND BUG")
                        : (_globalSenders.isEmpty
                              ? "GLOBAL KOSONG"
                              : "SEND BUG (GLOBAL)");
                    return Container(
                      width: double.infinity,
                      height: 54,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [theme.primaryColor, theme.accentColor],
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                        ),
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: theme.primaryColor.withOpacity(0.25 * glow),
                            blurRadius: 24,
                            spreadRadius: -2,
                          ),
                        ],
                      ),
                      child: ElevatedButton(
                        onPressed: (isSending || !canSend) ? null : _sendBug,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.transparent,
                          shadowColor: Colors.transparent,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                        ),
                        child: isSending
                            ? SizedBox(
                                width: 22,
                                height: 22,
                                child: CircularProgressIndicator(
                                  color: Colors.white,
                                  strokeWidth: 2.5,
                                ),
                              )
                            : Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    _selectedSenderType == 'global'
                                        ? Icons.public_rounded
                                        : Icons.rocket_launch_rounded,
                                    color: Colors.white,
                                    size: 20,
                                  ),
                                  const SizedBox(width: 8),
                                  Text(
                                    btnLabel,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 13,
                                      letterSpacing: 1.5,
                                    ),
                                  ),
                                ],
                              ),
                      ),
                    );
                  },
                ),

                // Response Message
                if (responseMessage != null) ...[
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: responseMessage!.contains('✅')
                          ? Colors.green.withOpacity(0.08)
                          : Colors.red.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: responseMessage!.contains('✅')
                            ? Colors.green.withOpacity(0.2)
                            : Colors.red.withOpacity(0.2),
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          responseMessage!.contains('✅')
                              ? Icons.check_circle
                              : Icons.error,
                          color: responseMessage!.contains('✅')
                              ? Colors.green
                              : Colors.red,
                          size: 18,
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            responseMessage!,
                            style: TextStyle(
                              color: responseMessage!.contains('✅')
                                  ? Colors.green
                                  : Colors.red,
                              fontWeight: FontWeight.w600,
                              fontSize: 12,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],

                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ],
    ));
  }

  Widget _statTile({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
    required ThemeProvider theme,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: theme.glassPrimary,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(0.18)),
      ),
      child: Row(
        children: [
          Container(
            width: 30,
            height: 30,
            decoration: BoxDecoration(
              color: color.withOpacity(0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: color, size: 16),
          ),
          const SizedBox(width: 9),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  value,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: theme.textPrimaryColor,
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 1),
                Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: theme.textSecondaryColor,
                    fontSize: 9,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.8,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildModeTab({
    required String label,
    required IconData icon,
    required String mode,
    required ThemeProvider theme,
  }) {
    final isActive = _selectedBugMode == mode;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() {
          _selectedBugMode = mode;
          targetController.clear();
          final bugList = mode == 'group' ? widget.listGroupBug : widget.listBug;
          if (bugList.isNotEmpty) {
            selectedBugId = bugList[0]['bug_id']?.toString() ?? "";
          }
        }),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            gradient: isActive
                ? LinearGradient(
                    colors: [theme.primaryColor, theme.accentColor],
                  )
                : null,
            color: isActive ? null : Colors.transparent,
            borderRadius: BorderRadius.circular(28),
            boxShadow: isActive
                ? [
                    BoxShadow(
                      color: theme.primaryColor.withOpacity(0.3),
                      blurRadius: 8,
                    ),
                  ]
                : [],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                color: isActive ? Colors.white : theme.textSecondaryColor,
                size: 18,
              ),
              const SizedBox(width: 7),
              Text(
                label,
                style: TextStyle(
                  color: isActive ? Colors.white : theme.textSecondaryColor,
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// Custom Grid Painter (DIUBAH AGAR PAKAI WARNA DARI THEME)
class _GridPainter extends CustomPainter {
  final Color accentColor;

  _GridPainter({required this.accentColor});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.02)
      ..strokeWidth = 0.8
      ..style = PaintingStyle.stroke;
    const gridSize = 30.0;
    for (double x = 0; x <= size.width; x += gridSize)
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    for (double y = 0; y <= size.height; y += gridSize)
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);

    final accentPaint = Paint()
      ..color = accentColor.withOpacity(0.08)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;
    for (double x = 0; x <= size.width; x += gridSize * 5)
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), accentPaint);
    for (double y = 0; y <= size.height; y += gridSize * 5)
      canvas.drawLine(Offset(0, y), Offset(size.width, y), accentPaint);

    final dotPaint = Paint()
      ..color = accentColor.withOpacity(0.1)
      ..style = PaintingStyle.fill;
    for (double x = 0; x <= size.width; x += gridSize) {
      for (double y = 0; y <= size.height; y += gridSize)
        canvas.drawCircle(Offset(x, y), 1.5, dotPaint);
    }
  }

  @override
  bool shouldRepaint(covariant _GridPainter oldDelegate) {
    return oldDelegate.accentColor != accentColor;
  }
}
