import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'config.dart';
import 'package:provider/provider.dart';
import 'theme_provider.dart';
import 'wa_report_page.dart';
import 'spam_pair_page.dart';

// ────────────── TOOLS PAGE ──────────────
class ToolsPage extends StatelessWidget {
  final String sessionKey;
  final String username;
  final String role;
  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Provider.of<ThemeProvider>(context);
    return Scaffold(
      backgroundColor: theme.backgroundColor,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            _glowIcon(Icons.build_rounded, theme.primaryColor, 18),
            const SizedBox(width: 8),
            Text(
              'TOOLS',
              style: TextStyle(
                color: theme.primaryColor,
                fontSize: 16,
                fontWeight: FontWeight.w900,
                letterSpacing: 4,
                shadows: [
                  Shadow(
                    color: theme.primaryColor.withOpacity(0.5),
                    blurRadius: 12,
                  ),
                ],
              ),
            ),
          ],
        ),
        iconTheme: IconThemeData(color: theme.primaryColor, size: 22),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(
                color: theme.textPrimaryColor.withOpacity(0.06),
                width: 1,
              ),
            ),
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                theme.primaryColor.withOpacity(0.08),
                Colors.transparent,
              ],
            ),
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _sectionHeader('ARMORY', 'Pilih alat serangan', theme),
            const SizedBox(height: 16),
            Expanded(
              child: GridView.count(
                crossAxisCount: 2,
                crossAxisSpacing: 14,
                mainAxisSpacing: 14,
                childAspectRatio: 0.82,
                children: [
                  _cyberCard(
                    icon: Icons.search_rounded,
                    label: 'OSINT',
                    desc: 'Intelligence\ngathering',
                    color: const Color(0xFF00B4FF),
                    gradient: const [Color(0xFF002244), Color(0xFF001133)],
                    theme: theme,
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => OsintToolPage(
                          sessionKey: sessionKey,
                          username: username,
                          role: role,
                        ),
                      ),
                    ),
                  ),
                  _cyberCard(
                    icon: Icons.phone_rounded,
                    label: 'PHONE\nLOOKUP',
                    desc: 'Number\ninvestigation',
                    color: const Color(0xFF00FF88),
                    gradient: const [Color(0xFF002211), Color(0xFF001108)],
                    theme: theme,
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => PhoneLookupPage(
                          sessionKey: sessionKey,
                          username: username,
                          role: role,
                        ),
                      ),
                    ),
                  ),
                  _cyberCard(
                    icon: Icons.warning_rounded,
                    label: 'DDoS',
                    desc: 'Targeted\nattack',
                    color: const Color(0xFFFF073A),
                    gradient: const [Color(0xFF220011), Color(0xFF110008)],
                    theme: theme,
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => DDoSToolPage(
                          sessionKey: sessionKey,
                          username: username,
                          role: role,
                        ),
                      ),
                    ),
                  ),
                  _cyberCard(
                    icon: Icons.report_rounded,
                    label: 'WA\nREPORT',
                    desc: 'Abuse\nreporting',
                    color: const Color(0xFFFFB300),
                    gradient: const [Color(0xFF221100), Color(0xFF110800)],
                    theme: theme,
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => WaReportPage(
                          sessionKey: sessionKey,
                          username: username,
                          role: role,
                        ),
                      ),
                    ),
                  ),
                  _cyberCard(
                    icon: Icons.wifi_tethering_rounded,
                    label: 'SPAM\nPAIR',
                    desc: 'Spam pairing\nWhatsApp',
                    color: const Color(0xFFFF6B35),
                    gradient: const [Color(0xFF221100), Color(0xFF110800)],
                    theme: theme,
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => SpamPairPage(
                          sessionKey: sessionKey,
                          username: username,
                          role: role,
                        ),
                      ),
                    ),
                  ),

                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionHeader(String title, String subtitle, ThemeProvider theme) {
    return Row(
      children: [
        Container(
          width: 3,
          height: 22,
          decoration: BoxDecoration(
            color: theme.primaryColor,
            borderRadius: BorderRadius.circular(2),
            boxShadow: [
              BoxShadow(
                color: theme.primaryColor.withOpacity(0.6),
                blurRadius: 8,
              ),
            ],
          ),
        ),
        const SizedBox(width: 10),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: TextStyle(
                color: theme.textPrimaryColor,
                fontSize: 13,
                fontWeight: FontWeight.w800,
                letterSpacing: 3,
              ),
            ),
            Text(
              subtitle,
              style: TextStyle(color: theme.textSecondaryColor, fontSize: 9),
            ),
          ],
        ),
      ],
    );
  }

  Widget _glowIcon(IconData icon, Color color, double size) {
    return Container(
      padding: EdgeInsets.all(size * 0.3),
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.4),
            blurRadius: 12,
            spreadRadius: -2,
          ),
        ],
      ),
      child: Icon(icon, color: color, size: size),
    );
  }

  Widget _cyberCard({
    required IconData icon,
    required String label,
    required String desc,
    required Color color,
    required List<Color> gradient,
    required ThemeProvider theme,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: TweenAnimationBuilder(
        duration: const Duration(milliseconds: 400),
        tween: Tween<double>(begin: 0, end: 1),
        builder: (context, double val, child) {
          return Transform.translate(
            offset: Offset(0, 30 * (1 - val)),
            child: Opacity(opacity: val, child: child),
          );
        },
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [theme.glassPrimary, theme.glassSecondary],
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: color.withOpacity(0.35), width: 1.2),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.1),
                blurRadius: 20,
                spreadRadius: -4,
              ),
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: gradient),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: color.withOpacity(0.5),
                          width: 1,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: color.withOpacity(0.3),
                            blurRadius: 10,
                          ),
                        ],
                      ),
                      child: Icon(icon, color: color, size: 22),
                    ),
                    const Spacer(),
                    Container(
                      width: 24,
                      height: 24,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: color.withOpacity(0.1),
                        border: Border.all(color: color.withOpacity(0.3)),
                      ),
                      child: Icon(
                        Icons.arrow_forward_rounded,
                        color: color,
                        size: 12,
                      ),
                    ),
                  ],
                ),
                const Spacer(),
                Text(
                  label,
                  style: TextStyle(
                    color: theme.textPrimaryColor,
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.5,
                    height: 1.2,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  desc,
                  style: TextStyle(
                    color: theme.textSecondaryColor,
                    fontSize: 10,
                    height: 1.3,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ────────────── OSINT TOOL ──────────────
class OsintToolPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;
  const OsintToolPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });
  @override
  State<OsintToolPage> createState() => _OsintToolPageState();
}

class _OsintToolPageState extends State<OsintToolPage>
    with SingleTickerProviderStateMixin {
  final _ctrl = TextEditingController();
  String _type = 'auto';
  bool _loading = false;
  Map<String, dynamic>? _result;
  String? _error;
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(
      begin: 0.6,
      end: 1,
    ).animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    _pulseCtrl.dispose();
    super.dispose();
  }

  Future<void> _search() async {
    final target = _ctrl.text.trim();
    if (target.isEmpty) return;
    setState(() {
      _loading = true;
      _result = null;
      _error = null;
    });
    await Future.delayed(const Duration(milliseconds: 300));
    final result = _localOsint(target, _type);
    setState(() {
      _result = result;
      _loading = false;
    });
  }

  Map<String, dynamic> _localOsint(String target, String type) {
    final sources = <Map<String, dynamic>>[];
    final cleanNum = target.replaceAll(RegExp(r'[^0-9]'), '');
    final isPhone = cleanNum.length >= 7 && cleanNum.length <= 15;
    final isEmail = target.contains('@');

    if (type == 'phone' || (type == 'auto' && isPhone)) {
      String country = 'Unknown';
      if (cleanNum.startsWith('62')) country = 'Indonesia (+62)';
      else if (cleanNum.startsWith('1')) country = 'US/Canada (+1)';
      else if (cleanNum.startsWith('44')) country = 'UK (+44)';
      else if (cleanNum.startsWith('91')) country = 'India (+91)';
      else if (cleanNum.startsWith('86')) country = 'China (+86)';

      String carrier = 'Unknown Carrier';
      if (RegExp(r'^628[123]').hasMatch(cleanNum)) carrier = 'Telkomsel';
      else if (RegExp(r'^628[56]').hasMatch(cleanNum)) carrier = 'Indosat';
      else if (RegExp(r'^628[78]').hasMatch(cleanNum)) carrier = 'XL Axiata';
      else if (RegExp(r'^6289').hasMatch(cleanNum)) carrier = 'Tri (3)';
      else if (RegExp(r'^6284').hasMatch(cleanNum)) carrier = 'Smartfren';

      sources.add({
        'name': 'Phone Analysis',
        'data': {
          'number': cleanNum,
          'country': country,
          'carrier': carrier,
          'valid': cleanNum.length >= 10 && cleanNum.length <= 15,
          'possibleApps': ['WhatsApp', 'Telegram', 'Signal'],
        }
      });
    }

    if (type == 'email' || (type == 'auto' && isEmail)) {
      final parts = target.split('@');
      final domain = parts.length > 1 ? parts[1] : 'unknown';
      final disposable = ['mailinator.com', 'guerrillamail.com', '10minutemail.com', 'tempmail.com',
        'throwaway.email', 'yopmail.com', 'sharklasers.com', 'trashmail.com'];
      sources.add({
        'name': 'Email Analysis',
        'data': {
          'email': target,
          'domain': domain,
          'username': parts[0],
          'disposable': disposable.contains(domain.toLowerCase()),
        }
      });
    }

    if (type == 'username' || type == 'auto') {
      sources.add({
        'name': 'Username Search',
        'data': {
          'username': target,
          'platforms': [
            {'name': 'WhatsApp', 'url': 'https://wa.me/$cleanNum'},
            {'name': 'Telegram', 'url': 'https://t.me/$target'},
            {'name': 'Instagram', 'url': 'https://instagram.com/$target'},
          ]
        }
      });
    }

    if (sources.isEmpty) {
      sources.add({
        'name': 'Analysis',
        'data': {'note': 'Could not determine target type. Try specifying phone, email, or username.'}
      });
    }

    return {'target': target, 'type': type, 'timestamp': DateTime.now().toIso8601String(), 'sources': sources};
  }

  Widget _infoRow(String label, dynamic value, ThemeProvider theme, Color color) {
    if (value == null || value.toString().isEmpty) return const SizedBox.shrink();
    return Container(
      width: double.infinity, margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [theme.glassPrimary, theme.glassSecondary], begin: Alignment.topLeft, end: Alignment.bottomRight),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withOpacity(0.1)),
      ),
      child: Row(children: [
        Text(label, style: TextStyle(color: theme.textSecondaryColor, fontSize: 11)),
        const Spacer(),
        Flexible(child: Text('$value', style: TextStyle(color: theme.textPrimaryColor, fontSize: 11, fontWeight: FontWeight.w600), textAlign: TextAlign.right)),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Provider.of<ThemeProvider>(context);
    const color = Color(0xFF00FF88);
    return Scaffold(
      backgroundColor: theme.backgroundColor,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text(
          'OSINT',
          style: TextStyle(
            color: color,
            fontSize: 15,
            fontWeight: FontWeight.w900,
            letterSpacing: 3,
            shadows: [Shadow(color: color.withOpacity(0.5), blurRadius: 10)],
          ),
        ),
        iconTheme: IconThemeData(color: color, size: 22),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [color.withOpacity(0.06), Colors.transparent],
            ),
            border: Border(
              bottom: BorderSide(color: Colors.white.withOpacity(0.05)),
            ),
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            _glassCard(
              context,
              color,
              theme,
              children: [
                TextField(
                  controller: _ctrl,
                  style: TextStyle(color: theme.textPrimaryColor, fontSize: 14),
                  decoration: _inputDecor(
                    'Target (phone/email/username)...',
                    Icons.search_rounded,
                    color,
                    theme,
                  ),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: ['Auto', 'Phone', 'Email', 'Username'].map((l) {
                    final v = l.toLowerCase();
                    final active = _type == v;
                    return GestureDetector(
                      onTap: () => setState(() => _type = v),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 14,
                          vertical: 7,
                        ),
                        decoration: BoxDecoration(
                          gradient: active
                              ? LinearGradient(
                                  colors: [
                                    color.withOpacity(0.2),
                                    color.withOpacity(0.1),
                                  ],
                                )
                              : null,
                          color: active ? null : theme.glassPrimary,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: active
                                ? color.withOpacity(0.6)
                                : theme.textSecondaryColor.withOpacity(0.12),
                          ),
                        ),
                        child: Text(
                          l,
                          style: TextStyle(
                            color: active ? color : theme.textSecondaryColor,
                            fontSize: 10,
                            fontWeight: active
                                ? FontWeight.bold
                                : FontWeight.normal,
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _loading ? null : _search,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: color,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 15),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      elevation: 8,
                      shadowColor: color.withOpacity(0.4),
                    ),
                    child: _loading
                        ? Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              ),
                              const SizedBox(width: 10),
                              const Text(
                                'SCANNING...',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 2,
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          )
                        : const Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.search_rounded, size: 18),
                              SizedBox(width: 8),
                              Text(
                                'EXECUTE',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 2,
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                  ),
                ),
              ],
            ),
            if (_error != null) _errorBanner(_error!, theme),
            if (_result != null) ...[
              const SizedBox(height: 16),
              _sectionLabel(
                'INTELLIGENCE REPORT',
                'Target: ${_result!['target']}',
                color,
                theme,
              ),
              const SizedBox(height: 10),
              ...(_result!['sources'] as List? ?? []).map(
                (s) => _sourceCard(s, color, theme),
              ),
            ],
          ],
        ),
      ),
    );
  }

  InputDecoration _inputDecor(
    String hint,
    IconData icon,
    Color color,
    ThemeProvider theme,
  ) {
    return InputDecoration(
      hintText: hint,
      hintStyle: TextStyle(color: theme.textSecondaryColor, fontSize: 13),
      prefixIcon: Icon(icon, color: color, size: 20),
      filled: true,
      fillColor: theme.backgroundColor,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: Colors.white.withOpacity(0.06)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: Colors.white.withOpacity(0.06)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: color, width: 1),
      ),
      contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
    );
  }

  Widget _glassCard(
    BuildContext context,
    Color color,
    ThemeProvider theme, {
    required List<Widget> children,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [theme.glassPrimary, theme.glassSecondary],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: color.withOpacity(0.2)),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.06),
            blurRadius: 20,
            spreadRadius: -4,
          ),
        ],
      ),
      child: Column(children: children),
    );
  }

  Widget _errorBanner(String msg, ThemeProvider theme) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 14),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.red.withOpacity(0.06),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.red.withOpacity(0.15)),
      ),
      child: Row(
        children: [
          const Icon(Icons.error_rounded, color: Colors.red, size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              msg,
              style: const TextStyle(color: Colors.red, fontSize: 11),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionLabel(
    String title,
    String sub,
    Color color,
    ThemeProvider theme,
  ) {
    return Row(
      children: [
        Container(
          width: 3,
          height: 18,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(2),
            boxShadow: [
              BoxShadow(color: color.withOpacity(0.6), blurRadius: 6),
            ],
          ),
        ),
        const SizedBox(width: 10),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: TextStyle(
                color: theme.textPrimaryColor,
                fontSize: 11,
                fontWeight: FontWeight.w800,
                letterSpacing: 2,
              ),
            ),
            Text(
              sub,
              style: TextStyle(color: theme.textSecondaryColor, fontSize: 9),
            ),
          ],
        ),
      ],
    );
  }

  Widget _sourceCard(dynamic source, Color color, ThemeProvider theme) {
    final name = source['name'] ?? 'Source';
    final data = source['data'] as Map<String, dynamic>? ?? {};
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [theme.glassPrimary, theme.glassSecondary],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(0.12)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 6,
                height: 6,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: color,
                  boxShadow: [
                    BoxShadow(color: color.withOpacity(0.6), blurRadius: 4),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Text(
                name,
                style: TextStyle(
                  color: color,
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          ...data.entries.map(
            (e) => Padding(
              padding: const EdgeInsets.only(bottom: 3),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${e.key}: ',
                    style: TextStyle(
                      color: theme.textSecondaryColor,
                      fontSize: 10,
                    ),
                  ),
                  Expanded(
                    child: Text(
                      '${e.value}',
                      style: TextStyle(
                        color: theme.textPrimaryColor,
                        fontSize: 10,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ────────────── PHONE LOOKUP ──────────────
class PhoneLookupPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;
  const PhoneLookupPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });
  @override
  State<PhoneLookupPage> createState() => _PhoneLookupPageState();
}

class _PhoneLookupPageState extends State<PhoneLookupPage> {
  final _ctrl = TextEditingController();
  bool _loading = false;
  Map<String, dynamic>? _result;
  String? _error;

  Future<void> _lookup() async {
    final num = _ctrl.text.trim();
    if (num.isEmpty) return;
    setState(() {
      _loading = true;
      _result = null;
      _error = null;
    });
    await Future.delayed(const Duration(milliseconds: 200));
    final data = _localPhoneLookup(num);
    setState(() {
      _result = data;
      _loading = false;
    });
  }

  Map<String, dynamic> _localPhoneLookup(String number) {
    final cleanNum = number.replaceAll(RegExp(r'[^0-9]'), '');
    String country = 'Unknown';
    if (cleanNum.startsWith('62')) country = 'Indonesia (+62)';
    else if (cleanNum.startsWith('1')) country = 'US/Canada (+1)';
    else if (cleanNum.startsWith('44')) country = 'UK (+44)';
    else if (cleanNum.startsWith('91')) country = 'India (+91)';
    else if (cleanNum.startsWith('86')) country = 'China (+86)';

    String carrier = 'Unknown Carrier';
    if (RegExp(r'^628[123]').hasMatch(cleanNum)) carrier = 'Telkomsel';
    else if (RegExp(r'^628[56]').hasMatch(cleanNum)) carrier = 'Indosat';
    else if (RegExp(r'^628[78]').hasMatch(cleanNum)) carrier = 'XL Axiata';
    else if (RegExp(r'^6289').hasMatch(cleanNum)) carrier = 'Tri (3)';
    else if (RegExp(r'^6284').hasMatch(cleanNum)) carrier = 'Smartfren';

    String region = 'Unknown Region';
    if (RegExp(r'^6282[123]').hasMatch(cleanNum) || RegExp(r'^6286[12]').hasMatch(cleanNum)) region = 'Jabodetabek';
    else if (RegExp(r'^6283[12]').hasMatch(cleanNum)) region = 'Jawa Barat';
    else if (RegExp(r'^6283[34]').hasMatch(cleanNum)) region = 'Jawa Tengah';
    else if (RegExp(r'^6283[56]').hasMatch(cleanNum)) region = 'Jawa Timur';
    else if (RegExp(r'^6286[12]').hasMatch(cleanNum)) region = 'Sumatera';

    return {
      'number': cleanNum,
      'formatted': cleanNum.isNotEmpty ? '+$cleanNum' : number,
      'country': country,
      'carrier': carrier,
      'valid': cleanNum.length >= 10 && cleanNum.length <= 15,
      'length': cleanNum.length,
      'type': cleanNum.length == 10 ? 'Mobile' : cleanNum.length > 12 ? 'International' : 'Local',
      'region': region,
      'timezone': country.contains('Indonesia') ? 'WIB/WITA/WIT' : 'UTC',
      'possibleApps': ['WhatsApp', 'Telegram', 'Signal'],
    };
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Provider.of<ThemeProvider>(context);
    const color = Color(0xFF00FF88);
    return Scaffold(
      backgroundColor: theme.backgroundColor,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text(
          'PHONE LOOKUP',
          style: TextStyle(
            color: color,
            fontSize: 15,
            fontWeight: FontWeight.w900,
            letterSpacing: 3,
            shadows: [Shadow(color: color.withOpacity(0.5), blurRadius: 10)],
          ),
        ),
        iconTheme: IconThemeData(color: color, size: 22),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [color.withOpacity(0.06), Colors.transparent],
            ),
            border: Border(
              bottom: BorderSide(color: Colors.white.withOpacity(0.05)),
            ),
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [theme.glassPrimary, theme.glassSecondary],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: color.withOpacity(0.2)),
                boxShadow: [
                  BoxShadow(color: color.withOpacity(0.06), blurRadius: 20),
                ],
              ),
              child: Column(
                children: [
                  TextField(
                    controller: _ctrl,
                    keyboardType: TextInputType.phone,
                    style: TextStyle(
                      color: theme.textPrimaryColor,
                      fontSize: 14,
                    ),
                    decoration: InputDecoration(
                      hintText: '628xx...',
                      hintStyle: TextStyle(
                        color: theme.textSecondaryColor,
                        fontSize: 13,
                      ),
                      prefixIcon: Icon(
                        Icons.phone_rounded,
                        color: color,
                        size: 20,
                      ),
                      filled: true,
                      fillColor: theme.backgroundColor,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(
                          color: Colors.white.withOpacity(0.06),
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(
                          color: Colors.white.withOpacity(0.06),
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(color: color, width: 1),
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                        vertical: 14,
                        horizontal: 12,
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _loading ? null : _lookup,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: color,
                        foregroundColor: Colors.black,
                        padding: const EdgeInsets.symmetric(vertical: 15),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        elevation: 8,
                        shadowColor: color.withOpacity(0.4),
                      ),
                      child: _loading
                          ? Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const SizedBox(
                                  width: 18,
                                  height: 18,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: Colors.black,
                                  ),
                                ),
                                const SizedBox(width: 10),
                                const Text(
                                  'PROCESSING...',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 2,
                                    fontSize: 12,
                                    color: Colors.black,
                                  ),
                                ),
                              ],
                            )
                          : const Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  Icons.search_rounded,
                                  size: 18,
                                  color: Colors.black,
                                ),
                                SizedBox(width: 8),
                                Text(
                                  'INVESTIGATE',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 2,
                                    fontSize: 12,
                                    color: Colors.black,
                                  ),
                                ),
                              ],
                            ),
                    ),
                  ),
                ],
              ),
            ),
            if (_error != null)
              Container(
                width: double.infinity,
                margin: const EdgeInsets.only(top: 14),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.red.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.red.withOpacity(0.15)),
                ),
                child: Row(
                  children: [
                    const Icon(
                      Icons.error_rounded,
                      color: Colors.red,
                      size: 16,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        _error!,
                        style: const TextStyle(color: Colors.red, fontSize: 11),
                      ),
                    ),
                  ],
                ),
              ),
            if (_result != null) ...[
              const SizedBox(height: 16),
              Row(
                children: [
                  Container(
                    width: 3,
                    height: 18,
                    decoration: BoxDecoration(
                      color: color,
                      borderRadius: BorderRadius.circular(2),
                      boxShadow: [
                        BoxShadow(color: color.withOpacity(0.6), blurRadius: 6),
                      ],
                    ),
                  ),
                  const SizedBox(width: 10),
                  Text(
                    'LOOKUP RESULT',
                    style: TextStyle(
                      color: theme.textPrimaryColor,
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 2,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              // === PERSONAL INFO SECTION ===
              if (_result!['name'] != null || _result!['email'] != null || _result!['address'] != null) ...[
                Row(children: [
                  Container(width: 3, height: 18, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(2), boxShadow: [BoxShadow(color: color.withOpacity(0.6), blurRadius: 6)])),
                  const SizedBox(width: 10),
                  Text('PERSONAL INFO', style: TextStyle(color: theme.textPrimaryColor, fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 2)),
                ]),
                const SizedBox(height: 10),
                if (_result!['name'] != null)
                  _infoRow('Name', _result!['name'], theme, color),
                if (_result!['email'] != null)
                  _infoRow('Email', _result!['email'], theme, color),
                if (_result!['address'] != null)
                  _infoRow('Address', _result!['address'], theme, color),
                if (_result!['city'] != null)
                  _infoRow('City', _result!['city'], theme, color),
                if (_result!['state'] != null)
                  _infoRow('State', _result!['state'], theme, color),
                if (_result!['zip'] != null)
                  _infoRow('ZIP', _result!['zip'], theme, color),
                const SizedBox(height: 16),
              ],
              // === SOCIAL MEDIA SECTION ===
              if (_result!['social_media'] != null && (_result!['social_media'] as Map).isNotEmpty) ...[
                Row(children: [
                  Container(width: 3, height: 18, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(2), boxShadow: [BoxShadow(color: color.withOpacity(0.6), blurRadius: 6)])),
                  const SizedBox(width: 10),
                  Text('SOCIAL MEDIA', style: TextStyle(color: theme.textPrimaryColor, fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 2)),
                ]),
                const SizedBox(height: 10),
                ...(_result!['social_media'] as Map).entries.map((e) => _infoRow(e.key, e.value, theme, color)),
                const SizedBox(height: 16),
              ],
              // === PHONE DETAILS ===
              Row(children: [
                Container(width: 3, height: 18, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(2), boxShadow: [BoxShadow(color: color.withOpacity(0.6), blurRadius: 6)])),
                const SizedBox(width: 10),
                Text('PHONE DETAILS', style: TextStyle(color: theme.textPrimaryColor, fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 2)),
              ]),
              const SizedBox(height: 10),
              ...[
                ('Number', _result!['formatted']),
                ('Country', _result!['country']),
                ('Carrier', _result!['carrier']),
                ('Region', _result!['region']),
                ('Type', _result!['type']),
                ('Timezone', _result!['timezone']),
                ('Length', _result!['length'] != null ? '${_result!['length']} digits' : '-'),
              ].map((e) => _infoRow(e.$1, e.$2, theme, color)),
              _infoRow('Valid', _result!['valid'] == true ? 'Yes' : 'No', theme,
                  _result!['valid'] == true ? color : Colors.red),
              if (_result!['possibleApps'] is List && (_result!['possibleApps'] as List).isNotEmpty) ...[
                const SizedBox(height: 14),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [theme.glassPrimary, theme.glassSecondary],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: color.withOpacity(0.12)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('DETECTED APPS', style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 2)),
                      const SizedBox(height: 10),
                      Wrap(
                        spacing: 6, runSpacing: 6,
                        children: (_result!['possibleApps'] as List).map((a) => Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(20), border: Border.all(color: color.withOpacity(0.3))),
                          child: Text('$a', style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.bold)),
                        )).toList(),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ],
        ),
      ),
    );
  }

  Widget _infoRow(String label, dynamic value, ThemeProvider theme, Color color) {
    if (value == null || value.toString().isEmpty) return const SizedBox.shrink();
    return Container(
      width: double.infinity, margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [theme.glassPrimary, theme.glassSecondary], begin: Alignment.topLeft, end: Alignment.bottomRight),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withOpacity(0.1)),
      ),
      child: Row(children: [
        Text(label, style: TextStyle(color: theme.textSecondaryColor, fontSize: 11)),
        const Spacer(),
        Flexible(child: Text('$value', style: TextStyle(color: theme.textPrimaryColor, fontSize: 11, fontWeight: FontWeight.w600), textAlign: TextAlign.right)),
      ]),
    );
  }
}

// ────────────── DDOS TOOL ──────────────
class DDoSToolPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;
  const DDoSToolPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });
  @override
  State<DDoSToolPage> createState() => _DDoSToolPageState();
}

class _DDoSToolPageState extends State<DDoSToolPage>
    with SingleTickerProviderStateMixin {
  final _targetCtrl = TextEditingController();
  final _portCtrl = TextEditingController();
  final _durationCtrl = TextEditingController();
  final _threadCtrl = TextEditingController(text: '10');
  final _vpsIpCtrl = TextEditingController();
  final _vpsPassCtrl = TextEditingController();
  String _method = 'HTTP';
  bool _sending = false;
  String? _result;
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(
      begin: 0.3,
      end: 0.7,
    ).animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _targetCtrl.dispose();
    _portCtrl.dispose();
    _durationCtrl.dispose();
    _threadCtrl.dispose();
    _vpsIpCtrl.dispose();
    _vpsPassCtrl.dispose();
    _pulseCtrl.dispose();
    super.dispose();
  }

  Future<void> _sendDDoS() async {
    final target = _targetCtrl.text.trim();
    final port = _portCtrl.text.trim();
    final duration = _durationCtrl.text.trim();
    final threads = _threadCtrl.text.trim();
    final vpsIp = _vpsIpCtrl.text.trim();
    final vpsPass = _vpsPassCtrl.text.trim();
    if (target.isEmpty) return;
    if (vpsIp.isEmpty || vpsPass.isEmpty) {
      setState(() => _result = '❌ VPS IP dan Password wajib diisi');
      return;
    }
    setState(() {
      _sending = true;
      _result = null;
    });
    try {
      final res = await http
          .post(
            Uri.parse('${ApiConfig.baseUrl}/api/ddos-run'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'key': widget.sessionKey,
              'vpsIp': vpsIp,
              'vpsPass': vpsPass,
              'target': target,
              'port': port.isEmpty ? '80' : port,
              'duration': duration.isEmpty ? '60' : duration,
              'method': _method,
              'threads': threads.isEmpty ? '10' : threads,
            }),
          )
          .timeout(const Duration(seconds: 30));
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        setState(
          () => _result =
              '✅ ${data['message'] ?? 'DDoS deployed successfully'}',
        );
      } else {
        setState(
          () => _result = '❌ Failed: ${data['error'] ?? "Unknown error"}',
        );
      }
    } catch (e) {
      setState(() => _result = '❌ Error: $e');
    } finally {
      setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Provider.of<ThemeProvider>(context);
    const color = Color(0xFFFF073A);
    return Scaffold(
      backgroundColor: theme.backgroundColor,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedBuilder(
              animation: _pulseAnim,
              builder: (context, _) {
                return Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: color,
                    boxShadow: [
                      BoxShadow(
                        color: color.withOpacity(_pulseAnim.value),
                        blurRadius: 8,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                );
              },
            ),
            const SizedBox(width: 10),
            Text(
              'DDoS',
              style: TextStyle(
                color: color,
                fontSize: 15,
                fontWeight: FontWeight.w900,
                letterSpacing: 3,
                shadows: [
                  Shadow(color: color.withOpacity(0.5), blurRadius: 10),
                ],
              ),
            ),
          ],
        ),
        iconTheme: IconThemeData(color: color, size: 22),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [color.withOpacity(0.08), Colors.transparent],
            ),
            border: Border(
              bottom: BorderSide(color: Colors.white.withOpacity(0.05)),
            ),
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [theme.glassPrimary, theme.glassSecondary],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: color.withOpacity(0.2)),
                boxShadow: [
                  BoxShadow(
                    color: color.withOpacity(0.06),
                    blurRadius: 20,
                    spreadRadius: -4,
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      AnimatedBuilder(
                        animation: _pulseAnim,
                        builder: (context, _) {
                          return Container(
                            width: 6,
                            height: 6,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: color,
                              boxShadow: [
                                BoxShadow(
                                  color: color.withOpacity(_pulseAnim.value),
                                  blurRadius: 4,
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'ATTACK PARAMETERS',
                        style: TextStyle(
                          color: color,
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 3,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _targetCtrl,
                    style: TextStyle(
                      color: theme.textPrimaryColor,
                      fontSize: 14,
                    ),
                    decoration: InputDecoration(
                      hintText: 'Target IP / URL',
                      hintStyle: TextStyle(
                        color: theme.textSecondaryColor,
                        fontSize: 13,
                      ),
                      prefixIcon: Icon(
                        Icons.language_rounded,
                        color: color,
                        size: 20,
                      ),
                      filled: true,
                      fillColor: theme.backgroundColor,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(
                          color: Colors.white.withOpacity(0.06),
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(
                          color: Colors.white.withOpacity(0.06),
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(color: color, width: 1),
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                        vertical: 14,
                        horizontal: 12,
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _portCtrl,
                          keyboardType: TextInputType.number,
                          style: TextStyle(
                            color: theme.textPrimaryColor,
                            fontSize: 14,
                          ),
                          decoration: InputDecoration(
                            hintText: 'Port',
                            hintStyle: TextStyle(
                              color: theme.textSecondaryColor,
                              fontSize: 13,
                            ),
                            prefixIcon: Icon(
                              Icons.settings_ethernet_rounded,
                              color: color,
                              size: 20,
                            ),
                            filled: true,
                            fillColor: theme.backgroundColor,
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide(
                                color: Colors.white.withOpacity(0.06),
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide(
                                color: Colors.white.withOpacity(0.06),
                              ),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide(color: color, width: 1),
                            ),
                            contentPadding: const EdgeInsets.symmetric(
                              vertical: 14,
                              horizontal: 12,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: TextField(
                          controller: _durationCtrl,
                          keyboardType: TextInputType.number,
                          style: TextStyle(
                            color: theme.textPrimaryColor,
                            fontSize: 14,
                          ),
                          decoration: InputDecoration(
                            hintText: 'Duration (s)',
                            hintStyle: TextStyle(
                              color: theme.textSecondaryColor,
                              fontSize: 13,
                            ),
                            prefixIcon: Icon(
                              Icons.timer_rounded,
                              color: color,
                              size: 20,
                            ),
                            filled: true,
                            fillColor: theme.backgroundColor,
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide(
                                color: Colors.white.withOpacity(0.06),
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide(
                                color: Colors.white.withOpacity(0.06),
                              ),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide(color: color, width: 1),
                            ),
                            contentPadding: const EdgeInsets.symmetric(
                              vertical: 14,
                              horizontal: 12,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _threadCtrl,
                    keyboardType: TextInputType.number,
                    style: TextStyle(
                      color: theme.textPrimaryColor,
                      fontSize: 14,
                    ),
                    decoration: InputDecoration(
                      hintText: 'Threads (10)',
                      hintStyle: TextStyle(
                        color: theme.textSecondaryColor,
                        fontSize: 13,
                      ),
                      prefixIcon: Icon(
                        Icons.memory_rounded,
                        color: color,
                        size: 20,
                      ),
                      filled: true,
                      fillColor: theme.backgroundColor,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(
                          color: Colors.white.withOpacity(0.06),
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(
                          color: Colors.white.withOpacity(0.06),
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(color: color, width: 1),
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                        vertical: 14,
                        horizontal: 12,
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      Container(
                        width: 3,
                        height: 14,
                        decoration: BoxDecoration(
                          color: color,
                          borderRadius: BorderRadius.circular(2),
                          boxShadow: [
                            BoxShadow(
                              color: color.withOpacity(0.6),
                              blurRadius: 4,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'METHOD',
                        style: TextStyle(
                          color: theme.textSecondaryColor,
                          fontSize: 9,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 2,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: ['HTTP', 'HTTPS', 'TCP', 'UDP', 'SYN'].map((l) {
                      final active = _method == l;
                      return GestureDetector(
                        onTap: () => setState(() => _method = l),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 14,
                            vertical: 7,
                          ),
                          decoration: BoxDecoration(
                            gradient: active
                                ? LinearGradient(
                                    colors: [
                                      color.withOpacity(0.2),
                                      color.withOpacity(0.1),
                                    ],
                                  )
                                : null,
                            color: active ? null : theme.glassPrimary,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: active
                                  ? color.withOpacity(0.6)
                                  : theme.textSecondaryColor.withOpacity(0.12),
                            ),
                          ),
                          child: Text(
                            l,
                            style: TextStyle(
                              color: active ? color : theme.textSecondaryColor,
                              fontSize: 10,
                              fontWeight: active
                                  ? FontWeight.bold
                                  : FontWeight.normal,
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 16),
                  Row(children: [
                    Container(width: 3, height: 14, decoration: BoxDecoration(color: const Color(0xFF00BCD4), borderRadius: BorderRadius.circular(2))),
                    const SizedBox(width: 8),
                    Text('VPS CONFIG', style: TextStyle(color: theme.textSecondaryColor, fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 2)),
                  ]),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _vpsIpCtrl,
                    style: TextStyle(color: theme.textPrimaryColor, fontSize: 14),
                    decoration: InputDecoration(
                      hintText: 'VPS IP Address', hintStyle: TextStyle(color: theme.textSecondaryColor, fontSize: 13),
                      prefixIcon: Icon(Icons.dns_rounded, color: const Color(0xFF00BCD4), size: 20),
                      filled: true, fillColor: theme.backgroundColor,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.white.withOpacity(0.06))),
                      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.white.withOpacity(0.06))),
                      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: const Color(0xFF00BCD4), width: 1)),
                      contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
                    ),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _vpsPassCtrl,
                    obscureText: true,
                    style: TextStyle(color: theme.textPrimaryColor, fontSize: 14),
                    decoration: InputDecoration(
                      hintText: 'VPS Password (root)', hintStyle: TextStyle(color: theme.textSecondaryColor, fontSize: 13),
                      prefixIcon: Icon(Icons.lock_rounded, color: const Color(0xFF00BCD4), size: 20),
                      filled: true, fillColor: theme.backgroundColor,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.white.withOpacity(0.06))),
                      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.white.withOpacity(0.06))),
                      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: const Color(0xFF00BCD4), width: 1)),
                      contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.red.withOpacity(0.04),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.red.withOpacity(0.1)),
                    ),
                    child: Row(
                      children: [
                        AnimatedBuilder(
                          animation: _pulseAnim,
                          builder: (context, _) {
                            return Icon(
                              Icons.warning_amber_rounded,
                              color: Colors.red.withOpacity(_pulseAnim.value),
                              size: 16,
                            );
                          },
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'Serangan dikirim via VPS pribadi. Pastikan IP dan password benar.',
                            style: const TextStyle(
                              color: Colors.red,
                              fontSize: 10,
                              height: 1.3,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 18),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: _sending ? null : _sendDDoS,
                      icon: _sending
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                          : const Icon(Icons.rocket_launch_rounded, size: 18),
                      label: Text(
                        _sending ? 'DEPLOYING...' : 'LAUNCH ATTACK',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          letterSpacing: 2,
                          fontSize: 12,
                        ),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: color,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        elevation: 8,
                        shadowColor: color.withOpacity(0.4),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            if (_result != null)
              Container(
                width: double.infinity,
                margin: const EdgeInsets.only(top: 14),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: _result!.startsWith('✅')
                      ? Colors.green.withOpacity(0.04)
                      : Colors.red.withOpacity(0.04),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: _result!.startsWith('✅')
                        ? Colors.green.withOpacity(0.15)
                        : Colors.red.withOpacity(0.15),
                  ),
                ),
                child: Text(
                  _result!,
                  style: TextStyle(
                    color: _result!.startsWith('✅') ? Colors.green : Colors.red,
                    fontSize: 11,
                    height: 1.4,
                  ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

